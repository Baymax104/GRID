#!/usr/bin/env bash
set -euo pipefail
export UV_NO_SYNC=1
source ./liger_common.sh
liger_launch train experiment=copmrec_scratch_train --group copmrec_scratch_ranking_v1 "$@"
