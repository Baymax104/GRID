#!/usr/bin/env bash
set -euo pipefail
source ./liger_common.sh
copmrec_ranker_launch() {
  local mode="$1" manifest="" evaluation="" checkpoint="" notes="" seed=42 flag value
  shift
  local -a extra=() args=()
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --dry-run) extra+=(--dry-run); shift; continue ;;
      --training-manifest|--evaluation-cache|--checkpoint|--notes|--seed)
        flag="$1"
        [[ $# -ge 2 && -n "$2" && "$2" != --* ]] || { echo "Error: $flag requires a value." >&2; return 2; }
        value="$2"; shift 2 ;;
      --training-manifest=*|--evaluation-cache=*|--checkpoint=*|--notes=*|--seed=*)
        flag="${1%%=*}"; value="${1#*=}"; shift ;;
      --*) echo "Error: unknown option $1" >&2; return 2 ;;
      *) extra+=("$1"); shift; continue ;;
    esac
    [[ -n "${value//[[:space:]]/}" ]] || { echo "Error: $flag requires a value." >&2; return 2; }
    case "$flag" in
      --training-manifest) manifest="$value" ;;
      --evaluation-cache) evaluation="$value" ;;
      --checkpoint) checkpoint="$value" ;;
      --notes) notes="$value" ;;
      --seed) seed="$value" ;;
    esac
  done
  [[ "$mode" == train || "$mode" == inference ]] || { echo "Error: invalid mode." >&2; return 2; }
  [[ -n "$manifest" && -n "$evaluation" && "$seed" =~ ^[0-9]+$ ]] || { echo "Error: manifest, evaluation cache and valid seed are required." >&2; return 2; }
  [[ "$mode" != inference || -n "$checkpoint" ]] || { echo "Error: checkpoint is required." >&2; return 2; }
  args=("experiment=copmrec_ranker_${mode}" "training_manifest_path=$(liger_quote_hydra_string "$manifest")"
    "evaluation_cache_path=$(liger_quote_hydra_string "$evaluation")" "seed=$seed")
  [[ -z "$checkpoint" ]] || args+=("ckpt_path=$(liger_quote_hydra_string "$checkpoint")")
  [[ -z "$notes" ]] || args+=("logger.wandb.notes=$(liger_quote_hydra_string "$notes")")
  uv run -m src.main "${args[@]}" "${extra[@]}"
}
