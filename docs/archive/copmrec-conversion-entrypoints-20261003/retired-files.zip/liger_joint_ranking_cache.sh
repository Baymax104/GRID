#!/usr/bin/env bash
set -euo pipefail
source ./liger_common.sh
liger_launch inference experiment=liger_joint_ranking_cache --group copmrec_ranker_training_cache_v1 "$@"
