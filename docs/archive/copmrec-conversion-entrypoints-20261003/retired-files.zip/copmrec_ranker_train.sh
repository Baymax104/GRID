#!/usr/bin/env bash
set -euo pipefail
source ./copmrec_ranker_common.sh
copmrec_ranker_launch train "$@"
