#!/usr/bin/env bash
set -euo pipefail
source ./liger_common.sh
liger_launch inference experiment=liger_joint_ranking_inference --group copmrec_mixture_ranking_v1 "$@"
