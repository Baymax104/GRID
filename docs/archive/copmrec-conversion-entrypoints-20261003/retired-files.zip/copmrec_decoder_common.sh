#!/usr/bin/env bash
set -euo pipefail
source ./liger_common.sh
copmrec_decoder_launch() {
  local mode="$1" manifest="" evaluation="" nll="" ndcg="" arm=ndcg notes="" flag value
  shift
  local -a extra=() args=()
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --dry-run) extra+=(--dry-run); shift; continue ;;
      --training-manifest|--evaluation-cache|--nll-checkpoint|--ndcg-checkpoint|--arm|--notes)
        flag="$1"; [[ $# -ge 2 && -n "$2" && "$2" != --* ]] || { echo "Error: $flag requires a value." >&2; return 2; }
        value="$2"; shift 2 ;;
      --training-manifest=*|--evaluation-cache=*|--nll-checkpoint=*|--ndcg-checkpoint=*|--arm=*|--notes=*)
        flag="${1%%=*}"; value="${1#*=}"; shift ;;
      --*) echo "Error: unknown option $1" >&2; return 2 ;;
      *) extra+=("$1"); shift; continue ;;
    esac
    [[ -n "${value//[[:space:]]/}" ]] || { echo "Error: empty $flag" >&2; return 2; }
    case "$flag" in
      --training-manifest) manifest="$value" ;;
      --evaluation-cache) evaluation="$value" ;;
      --nll-checkpoint) nll="$value" ;;
      --ndcg-checkpoint) ndcg="$value" ;;
      --arm) arm="$value" ;;
      --notes) notes="$value" ;;
    esac
  done
  [[ "$arm" == nll || "$arm" == ndcg ]] && [[ -n "$manifest" && -n "$evaluation" ]] || { echo "Error: arm and cache paths required." >&2; return 2; }
  [[ "$mode" == train || "$mode" == audit ]] || return 2
  [[ "$mode" != audit || ( -n "$nll" && -n "$ndcg" ) ]] || { echo "Error: both audit checkpoints required." >&2; return 2; }
  args=("experiment=copmrec_decoder_$mode" "training_manifest_path=$(liger_quote_hydra_string "$manifest")"
    "evaluation_cache_path=$(liger_quote_hydra_string "$evaluation")" "ranking_arm=$arm")
  [[ -z "$nll" ]] || args+=("nll_checkpoint=$(liger_quote_hydra_string "$nll")")
  [[ -z "$ndcg" ]] || args+=("ndcg_checkpoint=$(liger_quote_hydra_string "$ndcg")")
  [[ -z "$notes" ]] || args+=("logger.wandb.notes=$(liger_quote_hydra_string "$notes")")
  uv run -m src.main "${args[@]}" "${extra[@]}"
}
