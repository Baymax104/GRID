#!/usr/bin/env bash
set -euo pipefail
source ./copmrec_decoder_common.sh
copmrec_decoder_launch audit "$@"
