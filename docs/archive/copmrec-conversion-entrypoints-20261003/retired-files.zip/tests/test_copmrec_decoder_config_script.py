import shlex
import subprocess
from pathlib import Path

import pytest
from bash_fixture import bash as bash_fixture
from hydra import compose, initialize_config_dir

import src.utils.hydra_resolvers  # noqa: F401
from src.utils.launcher import apply_dry_run_overrides

bash = bash_fixture
ROOT = Path(__file__).resolve().parents[1]


def test_decoder_configs_preserve_controls():
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        t = compose(config_name="main", overrides=["experiment=copmrec_decoder_train"])
        a = compose(config_name="main", overrides=["experiment=copmrec_decoder_audit"])
    assert t.model.metrics is None and not t.run_test_after_training and t.ckpt_path is None
    assert t.trainer.root.max_epochs == 20 and t.trainer.root.accumulate_grad_batches == 4
    assert t.trainer.root.check_val_every_n_epoch == 2 and t.data.datamodule.batch_size == 8
    assert t.model.root.ranking_chunk_size == 64 and t.trainer.root.precision == "32-true"
    assert t.model.root.cpu_threads == 4
    assert t.model.root.boundary_gradient_fraction == 0
    assert t.model.root.content_preservation_weight == 0
    assert t.model.root.pairwise_normalization == "per_user"
    assert t.model.root.preservation_teacher_scope == "content"
    assert t.model.root.pairwise_candidate_scope == "all" and t.model.root.pairwise_competitive_k == 20
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        competitive = compose(
            config_name="main",
            overrides=[
                "experiment=copmrec_decoder_train",
                "model.root.pairwise_candidate_scope=competitive",
                "model.root.pairwise_competitive_k=20",
                "model.root.content_preservation_weight=1.0",
                "model.root.preservation_teacher_scope=content_generation",
                "model.root.pairwise_normalization=training_mean_cap",
                "model.root.boundary_gradient_fraction=0.25",
            ],
        )
    assert competitive.model.root.pairwise_candidate_scope == "competitive"
    assert competitive.model.root.content_preservation_weight == 1.0
    assert competitive.model.root.preservation_teacher_scope == "content_generation"
    assert competitive.model.root.pairwise_normalization == "training_mean_cap"
    assert competitive.model.root.boundary_gradient_fraction == 0.25
    assert a.model.root._target_.endswith("DualDecoderRanking")
    assert a.callbacks.tiger_prediction_metrics is None
    a.dry_run = True
    apply_dry_run_overrides(a)
    assert a.callbacks.copmrec_ranking_writer is None


@pytest.mark.parametrize("mode", ["train", "audit"])
@pytest.mark.parametrize("equals", [False, True])
def test_decoder_script_quotes_passthrough(bash, mode, equals):
    notes = 'literal $(not_executed) "quoted"'
    args = [
        "--training-manifest",
        "cache dir/manifest.json",
        "--evaluation-cache",
        "eval.pt",
        *(["--nll-checkpoint", "nll.ckpt", "--ndcg-checkpoint", "ndcg.ckpt"] if mode == "audit" else ["--arm", "nll"]),
        *(["--notes=" + notes] if equals else ["--notes", notes]),
        "--dry-run",
        "model.root.ranking_chunk_size=2",
        "model.root.pairwise_candidate_scope=competitive",
        "model.root.content_preservation_weight=1.0",
        "model.root.preservation_teacher_scope=content_generation",
        "model.root.pairwise_normalization=training_mean_cap",
        "model.root.boundary_gradient_fraction=0.25",
    ]
    command = 'uv() { printf "%s\\n" "$@"; }; export -f uv; bash ' + shlex.join(
        ["copmrec_decoder_" + mode + ".sh", *args]
    )
    r = subprocess.run([bash], input=command, cwd=ROOT, text=True, capture_output=True)
    assert r.returncode == 0, r.stderr
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        cfg = compose(config_name="main", overrides=[v for v in r.stdout.splitlines()[3:] if v != "--dry-run"])
    assert cfg.logger.wandb.notes == notes and cfg.training_manifest_path == "cache dir/manifest.json"
    assert cfg.model.root.ranking_chunk_size == 2
    assert cfg.model.root.pairwise_candidate_scope == "competitive"
    assert cfg.model.root.content_preservation_weight == 1.0
    assert cfg.model.root.preservation_teacher_scope == "content_generation"
    assert cfg.model.root.pairwise_normalization == "training_mean_cap"
    assert cfg.model.root.boundary_gradient_fraction == 0.25


def test_script_syntax_and_invalid_arguments(bash):
    for p in ["copmrec_decoder_common.sh", "copmrec_decoder_train.sh", "copmrec_decoder_audit.sh"]:
        assert subprocess.run([bash, "-n", p], cwd=ROOT).returncode == 0
    for args in [["--arm", "bad"], ["--notes="], ["--training-manifest"], ["--unknown"]]:
        assert subprocess.run([bash, "copmrec_decoder_train.sh", *args], cwd=ROOT, capture_output=True).returncode == 2
    assert (
        subprocess.run(
            [bash, "copmrec_decoder_audit.sh", "--training-manifest", "x", "--evaluation-cache", "y"],
            cwd=ROOT,
            capture_output=True,
        ).returncode
        == 2
    )
