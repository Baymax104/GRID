import shlex
import subprocess
from pathlib import Path

import pytest
from bash_fixture import bash as bash_fixture
from hydra import compose, initialize_config_dir

import src.utils.hydra_resolvers  # noqa: F401
from src.utils.launcher import apply_dry_run_overrides

ROOT = Path(__file__).resolve().parents[1]
bash = bash_fixture


def test_ranking_default_split_and_baseline_configs():
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        new = compose(
            config_name="main", overrides=["experiment=liger_joint_ranking_inference", "data_dir=data/beauty"]
        )
        old = compose(config_name="main", overrides=["experiment=liger_inference"])
        joint = compose(config_name="main", overrides=["experiment=liger_joint_inference"])
    assert new.data.predict_dataloader.data_folder == "data/beauty/evaluation"
    assert new.model.root._target_.endswith("MixtureRankingLiger")
    assert new.model.root.ranking_mode == "mixed"
    assert "liger_trace_writer" not in new.callbacks
    assert old.model.root._target_.endswith(".Liger")
    assert joint.model.root._target_.endswith(".JointMixtureLiger")
    new.dry_run = True
    apply_dry_run_overrides(new)
    assert new.callbacks.copmrec_ranking_writer is None


@pytest.mark.parametrize("equals", [False, True])
def test_ranking_launcher_notes_overrides_and_syntax(bash, equals):
    checked = subprocess.run([bash, "-n", "liger_joint_ranking_inference.sh"], cwd=ROOT, capture_output=True)
    assert checked.returncode == 0
    note = 'literal $(no_execution) "quoted" \\ value'
    args = [
        "--data-dir",
        "data/beauty",
        "--dataset",
        "beauty",
        "--devices",
        "[0]",
        "--semantic-id-path",
        "sid.pt",
        "--embedding-path",
        "embedding.pt",
        "--checkpoint",
        "best.ckpt",
        "--dry-run",
        *(["--notes=" + note] if equals else ["--notes", note]),
        "model.root.ranking_chunk_size=2",
        "seed=42",
        "+logger.wandb.tags=[copmrec_ranking_dev_20261001]",
    ]
    command = 'uv() { printf "%s\\n" "$@"; }; export -f uv; '
    command += "bash " + shlex.join(["liger_joint_ranking_inference.sh", *args])
    result = subprocess.run([bash], input=command, cwd=ROOT, text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    argv = result.stdout.splitlines()
    assert argv[:3] == ["run", "-m", "src.main"] and "--dry-run" in argv
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        cfg = compose(config_name="main", overrides=[v for v in argv[3:] if v != "--dry-run"])
    assert cfg.model.root.ranking_chunk_size == 2
    assert cfg.logger.wandb.notes == note
    assert list(cfg.logger.wandb.tags) == ["copmrec_ranking_dev_20261001"]
    assert cfg.model.root._target_.endswith("MixtureRankingLiger")


@pytest.mark.parametrize("bad", ["--notes", "--notes=", "--unknown"])
def test_ranking_launcher_bad_options(bash, bad):
    result = subprocess.run([bash, "liger_joint_ranking_inference.sh", bad], cwd=ROOT, capture_output=True)
    assert result.returncode == 2
