import shlex
import subprocess
from pathlib import Path

import pytest
from bash_fixture import bash as bash_fixture
from hydra import compose, initialize_config_dir

import src.utils.hydra_resolvers  # noqa: F401
from src.utils.launcher import apply_dry_run_overrides

bash = bash_fixture
ROOT = Path(__file__).resolve().parents[1]


def test_cache_and_learning_configs_are_isolated():
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        cache = compose(config_name="main", overrides=["experiment=liger_joint_ranking_cache", "data_dir=data/beauty"])
        train = compose(config_name="main", overrides=["experiment=copmrec_ranker_train"])
        inference = compose(config_name="main", overrides=["experiment=copmrec_ranker_inference"])
    assert cache.data.predict_dataloader.data_folder == "data/beauty/training"
    assert cache.callbacks.wandb_artifact_writer is None
    assert not cache.callbacks.copmrec_ranking_writer.publish_wandb
    assert train.model.root._target_.endswith("PairwiseCandidateRanker")
    assert train.trainer.root.max_epochs == 10 and train.trainer.root.accelerator == "cpu"
    assert train.data.datamodule._target_.endswith("CopmrecRankerDataModule")
    assert inference.callbacks.tiger_prediction_metrics is None
    cache.dry_run = True
    apply_dry_run_overrides(cache)
    assert cache.callbacks.copmrec_ranking_writer is None


@pytest.mark.parametrize("mode", ["train", "inference"])
@pytest.mark.parametrize("equals", [False, True])
def test_ranker_scripts_quote_notes_paths_and_overrides(bash, mode, equals):
    script = f"copmrec_ranker_{mode}.sh"
    note = 'literal $(no_execution) "quoted"'
    args = [
        "--training-manifest",
        "cache dir/manifest.json",
        "--evaluation-cache",
        "evaluation.pt",
        *(["--checkpoint", "head.ckpt"] if mode == "inference" else []),
        *(["--notes=" + note] if equals else ["--notes", note]),
        "--dry-run",
        "model.root.learning_rate=0.002",
    ]
    command = 'uv() { printf "%s\\n" "$@"; }; export -f uv; bash ' + shlex.join([script, *args])
    result = subprocess.run([bash], input=command, cwd=ROOT, text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    argv = result.stdout.splitlines()
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        cfg = compose(config_name="main", overrides=[a for a in argv[3:] if a != "--dry-run"])
    assert cfg.training_manifest_path == "cache dir/manifest.json"
    assert cfg.logger.wandb.notes == note and cfg.model.root.learning_rate == 0.002


def test_all_new_scripts_syntax_and_bad_arguments(bash):
    for script in (
        "copmrec_ranker_common.sh",
        "copmrec_ranker_train.sh",
        "copmrec_ranker_inference.sh",
        "liger_joint_ranking_cache.sh",
    ):
        assert subprocess.run([bash, "-n", script], cwd=ROOT).returncode == 0
    for args in (
        ["--notes="],
        ["--unknown"],
        ["--training-manifest"],
        ["--training-manifest", "x", "--evaluation-cache", "y", "--seed", "bad"],
    ):
        assert subprocess.run([bash, "copmrec_ranker_train.sh", *args], cwd=ROOT, capture_output=True).returncode == 2
