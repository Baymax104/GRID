import shlex
import subprocess
from pathlib import Path

import pytest
from bash_fixture import bash as bash_fixture
from hydra import compose, initialize_config_dir

import src.utils.hydra_resolvers  # noqa: F401
from src.utils.launcher import apply_dry_run_overrides

bash = bash_fixture
ROOT = Path(__file__).resolve().parents[1]


def config(mode):
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        return compose(config_name="main", overrides=[f"experiment=copmrec_scratch_{mode}"])


def test_scratch_config_and_dry_run():
    c = config("train")
    assert c.ckpt_path is None and c.trainer.root.max_steps == 50000
    assert c.model.root.foundation_steps == 25000 and c.model.root.calibration_batches == 128
    assert c.data.train_dataloader.batch_size_per_device * c.trainer.root.accumulate_grad_batches == 256
    assert c.trainer.root.val_check_interval == 5000 and c.model.metrics is None
    assert c.callbacks.model_checkpoint.monitor == "val/selection_ndcg@10"
    assert "initial_checkpoint_path" not in c.model.root and "training_manifest_path" not in c
    c.dry_run = True
    apply_dry_run_overrides(c)
    assert c.trainer.root.max_steps == 1 and c.callbacks.model_checkpoint is None
    a = config("audit")
    assert a.run_mode == "inference" and a.callbacks.scratch_trace.publish_wandb
    a.dry_run = True
    apply_dry_run_overrides(a)
    assert a.callbacks.scratch_trace is None


def test_scratch_ddp2_preserves_update_and_sampling_budget():
    c = config("train_ddp2")
    assert c.data.train_dataloader.batch_size_per_device * 2 * c.trainer.root.accumulate_grad_batches == 256
    assert c.model.root.ranking_batch_size * 2 * c.trainer.root.accumulate_grad_batches == 16
    assert c.model.root.calibration_batches == 128
    assert c.trainer.root.max_steps == 50000 and c.trainer.root.val_check_interval == 5000
    assert c.trainer.root.strategy.broadcast_buffers is False
    assert c.trainer.root.strategy.find_unused_parameters is True
    assert c.trainer.root.use_distributed_sampler is False


@pytest.mark.parametrize("mode", ["train", "audit"])
@pytest.mark.parametrize("equals", [True, False])
def test_script_quotes_overrides(bash, mode, equals):
    notes = 'literal $(no_execution) "quoted"'
    args = [
        "--dataset",
        "beauty",
        "--data-dir",
        "data dir",
        "--semantic-id-path",
        "sid.pt",
        "--embedding-path",
        "embedding.pt",
        "--devices",
        "[6]",
        *(["--checkpoint", "saved.ckpt"] if mode == "audit" else []),
        *(["--notes=" + notes] if equals else ["--notes", notes]),
        "--dry-run",
        "model.root.ranking_batch_size=3",
    ]
    command = 'uv() { printf "%s\\n" "$@"; }; export -f uv; bash ' + shlex.join(
        ["copmrec_scratch_" + mode + ".sh", *args]
    )
    result = subprocess.run([bash], input=command, cwd=ROOT, text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    with initialize_config_dir(config_dir=str(ROOT / "configs"), version_base="1.3"):
        c = compose(config_name="main", overrides=[x for x in result.stdout.splitlines()[3:] if x != "--dry-run"])
    assert c.logger.wandb.notes == notes and c.data_dir == "data dir"
    assert c.model.root.ranking_batch_size == 3


def test_script_syntax_invalid(bash):
    for mode in ["train", "audit"]:
        assert subprocess.run([bash, "-n", "copmrec_scratch_" + mode + ".sh"], cwd=ROOT).returncode == 0
        for args in [["--notes="], ["--devices"], ["--unknown"]]:
            result = subprocess.run(
                [bash, "copmrec_scratch_" + mode + ".sh", *args], cwd=ROOT, capture_output=True, text=True
            )
            assert result.returncode == 2
